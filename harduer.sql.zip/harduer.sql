-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Време на генериране:  6 юни 2021 в 12:47
-- Версия на сървъра: 10.4.18-MariaDB
-- Версия на PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данни: `harduer`
--
CREATE DATABASE IF NOT EXISTS `harduer` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `harduer`;

-- --------------------------------------------------------

--
-- Структура на таблица `motherboards`
--

DROP TABLE IF EXISTS `motherboards`;
CREATE TABLE `motherboards` (
  `md_id` int(10) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `snimka` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `motherboards`
--

INSERT INTO `motherboards` (`md_id`, `brand`, `model`, `price`, `snimka`) VALUES
(4, 'asdasd', 'asdasd', 5555, 'sdsa');

-- --------------------------------------------------------

--
-- Структура на таблица `processors`
--

DROP TABLE IF EXISTS `processors`;
CREATE TABLE `processors` (
  `prc_id` int(20) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `price` int(50) NOT NULL,
  `snimka` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `processors`
--

INSERT INTO `processors` (`prc_id`, `brand`, `model`, `price`, `snimka`) VALUES
(1, 'asdasd', 'asdasd', 12321, 'asdas'),
(4, '', '', 0, '');

-- --------------------------------------------------------

--
-- Структура на таблица `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `password` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `users`
--

INSERT INTO `users` (`id`, `username`, `first_name`, `last_name`, `password`) VALUES
(1, 'koceto', 'asd', 'asdasd', 0),
(2, 'koceto', '', '', 0);

--
-- Indexes for dumped tables
--

--
-- Индекси за таблица `motherboards`
--
ALTER TABLE `motherboards`
  ADD PRIMARY KEY (`md_id`);

--
-- Индекси за таблица `processors`
--
ALTER TABLE `processors`
  ADD PRIMARY KEY (`prc_id`);

--
-- Индекси за таблица `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `motherboards`
--
ALTER TABLE `motherboards`
  MODIFY `md_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `processors`
--
ALTER TABLE `processors`
  MODIFY `prc_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
